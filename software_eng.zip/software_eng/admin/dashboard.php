<?php
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("❌ Connection failed: " . mysqli_connect_error());
}

// Get stats
$total_books = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM books"))[0];
$borrowed_books = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM books WHERE status = 'Borrowed'"))[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard | Library System</title>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background-color: #f4f6f9;
      margin: 0;
    }

    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }

    nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    nav a:hover {
      background-color: #1abc9c;
    }

    .dashboard-container {
      max-width: 900px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    .cards {
      display: flex;
      gap: 30px;
      justify-content: space-around;
      flex-wrap: wrap;
    }

    .card {
      flex: 1 1 200px;
      background-color: #ecf0f1;
      padding: 25px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 1px 6px rgba(0,0,0,0.1);
    }

    .card h3 {
      margin: 0;
      font-size: 18px;
      color: #34495e;
    }

    .card p {
      font-size: 32px;
      color: #1abc9c;
      margin-top: 10px;
    }

    footer {
      text-align: center;
      padding: 20px;
      color: #888;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <header>
    <h1> Admin Dashboard - Library System</h1>
  </header>

  <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_books.php">Manage Books</a>
    <a href="add_book.html">Add Book</a>
    <a href="manage_members.php">Manage Members</a>
    <a href="reports.php">Reports</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="dashboard-container">
    <h2>📊 System Overview</h2>
    <div class="cards">
      <div class="card">
        <h3>Total Books</h3>
        <p><?php echo $total_books; ?></p>
      </div>
      <div class="card">
        <h3>Borrowed Books</h3>
        <p><?php echo $borrowed_books; ?></p>
      </div>
      <!-- You can add more cards here for total members, active users, etc. -->
    </div>
  </div>

  <footer>
    &copy; <?php echo date("Y"); ?> Library Management System - Admin Panel
  </footer>

</body>
</html>
