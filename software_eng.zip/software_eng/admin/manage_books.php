<?php
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("❌ Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM books ORDER BY id DESC";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Books | Admin</title>
  <style>
    body { font-family: Arial; background-color: #f4f6f9; margin: 0; }
    header, nav { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
    nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    nav a:hover {
      background-color: #1abc9c;
    }
    .container { max-width: 1000px; margin: 40px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    h2 { color: #2c3e50; text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border-bottom: 1px solid #ccc; text-align: left; }
    .actions a { text-decoration: none; margin-right: 10px; font-weight: bold; }
    .edit { color: #2980b9; }
    .delete { color: #c0392b; }
    .add-book-btn {
      background: #1abc9c; color: white; padding: 10px 16px; text-decoration: none;
      border-radius: 5px; display: inline-block; margin-bottom: 20px;
    }
    .add-book-btn:hover { background: #16a085; }
  </style>
</head>
<body>

<header>
  <h1>📘 Admin - Manage Books</h1>
</header>

  <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_books.php">Manage Books</a>
    <a href="add_book.html">Add Book</a>
    <a href="manage_members.php">Manage Members</a>
    <a href="reports.php">Reports</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

<div class="container">
  <a href="add_book.html" class="add-book-btn">➕ Add New Book</a>

  <h2>📚 Book List</h2>
  <table>
    <thead>
      <tr>
        <th>Title</th>
        <th>Author</th>
        <th>Category</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['title']); ?></td>
          <td><?php echo htmlspecialchars($row['author']); ?></td>
          <td><?php echo htmlspecialchars($row['category']); ?></td>
          <td><?php echo htmlspecialchars($row['status']); ?></td>
          <td class="actions">
            <a href="edit_book.php?id=<?php echo $row['id']; ?>" class="edit">Edit</a>
            <a href="delete_book.php?id=<?php echo $row['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this book?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

</body>
</html>
