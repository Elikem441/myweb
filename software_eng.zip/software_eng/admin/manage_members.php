<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch all members
$query = "SELECT * FROM users WHERE role = 'user'";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Members | Admin</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; }
    header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
    .container { padding: 30px; max-width: 1000px; margin: auto; background-color: white; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    nav a:hover {
      background-color: #1abc9c;
    }
    h2 { color: #2c3e50; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
    th { background-color: #34495e; color: white; }
    tr:hover { background-color: #f1f1f1; }
    .action-btn {
      padding: 6px 10px;
      font-size: 14px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
    }
    .edit-btn { background-color: #3498db; color: white; }
    .delete-btn { background-color: #e74c3c; color: white; }
  </style>
</head>
<body>

  <header>
    <h1>Admin Panel - Manage Members</h1>
  </header>
  <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_books.php">Manage Books</a>
    <a href="add_book.html">Add Book</a>
    <a href="manage_members.php">Manage Members</a>
    <a href="reports.php">Reports</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <h2>Registered Members</h2>

    <table>
<thead>
  <tr>
    <th>ID</th>
    <th>Full Name</th>
    <th>Member ID</th>
    <th>Email</th>
    <th>Date Joined</th>
    <th>Actions</th>
  </tr>
</thead>
      <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= htmlspecialchars($row['name']) ?></td>
              <td><?= htmlspecialchars($row['member_id']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= $row['created_at'] ?></td>
              <td>
                <a class="action-btn edit-btn" href="edit_members.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="action-btn delete-btn" href="delete_members.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this member?');">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6">No members found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</body>
</html>
