<?php
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Card summaries
$total_books     = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM books"))[0];
$borrowed_books  = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM books WHERE status = 'Borrowed'"))[0];
$overdue_books   = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM borrowed_books WHERE due_date < CURDATE() AND status != 'Returned'"))[0];
$total_members   = mysqli_fetch_row(mysqli_query($connection, "SELECT COUNT(*) FROM users"))[0];

// Recent borrowing records
$borrowing_query = "
  SELECT u.name AS member_name, b.title AS book_title, br.borrow_date, br.due_date, br.status
  FROM borrowed_books br
  JOIN users u ON br.user_id = u.id
  JOIN books b ON br.book_id = b.id
  ORDER BY br.borrow_date DESC
  LIMIT 10
";
$borrowing_result = mysqli_query($connection, $borrowing_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reports - Library System</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
    }

    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }

    

    .container {
      padding: 30px;
      max-width: 1100px;
      margin: auto;
    }

       nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    nav a:hover {
      background-color: #1abc9c;
    }

    h2 {
      color: #2c3e50;
      margin-bottom: 20px;
    }

    .cards {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 30px;
    }

    .card {
      background-color: white;
      flex: 1 1 250px;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .card h3 {
      margin: 0;
      color: #34495e;
    }

    .card p {
      font-size: 1.4em;
      color: #1abc9c;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
      background-color: white;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: #34495e;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }
  </style>
</head>
<body>

  <header>
    <h1>Library Management System</h1>
    <h2>Reports</h2>
  </header>
   <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_books.php">Manage Books</a>
    <a href="add_book.html">Add Book</a>
    <a href="manage_members.php">Manage Members</a>
    <a href="reports.php">Reports</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <div class="cards">
      <div class="card">
        <h3>Total Books</h3>
        <p><?php echo $total_books; ?></p>
      </div>
      <div class="card">
        <h3>Books Borrowed</h3>
        <p><?php echo $borrowed_books; ?></p>
      </div>
      <div class="card">
        <h3>Overdue Books</h3>
        <p><?php echo $overdue_books; ?></p>
      </div>
      <div class="card">
        <h3>Total Members</h3>
        <p><?php echo $total_members; ?></p>
      </div>
    </div>

    <h2>Recent Borrowing Activity</h2>
    <table>
      <thead>
        <tr>
          <th>Member Name</th>
          <th>Book Title</th>
          <th>Borrow Date</th>
          <th>Due Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($borrowing_result) > 0): ?>
          <?php while($row = mysqli_fetch_assoc($borrowing_result)): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['member_name']); ?></td>
              <td><?php echo htmlspecialchars($row['book_title']); ?></td>
              <td><?php echo htmlspecialchars($row['borrow_date']); ?></td>
              <td><?php echo htmlspecialchars($row['due_date']); ?></td>
              <td><?php echo htmlspecialchars($row['status']); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="5">No borrowing records available.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</body>
</html>
