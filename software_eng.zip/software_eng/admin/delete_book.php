<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("❌ Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM books WHERE id = $id";

    if (mysqli_query($connection, $query)) {
        echo "✅ Book deleted successfully. <a href='manage_books.php'>Go back</a>";
    } else {
        echo "❌ Deletion failed: " . mysqli_error($connection);
    }
} else {
    echo "⚠️ No book ID provided.";
}
?>
