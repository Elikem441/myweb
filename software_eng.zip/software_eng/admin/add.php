<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");

if (!$connection) {
    echo "❌ Database connection failed.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = mysqli_real_escape_string($connection, $_POST['title'] ?? '');
    $author   = mysqli_real_escape_string($connection, $_POST['author'] ?? '');
    $category = mysqli_real_escape_string($connection, $_POST['category'] ?? '');
    $status   = mysqli_real_escape_string($connection, $_POST['status'] ?? '');

    if (empty($title) || empty($author) || empty($status)) {
        echo "⚠️ Please fill in all required fields.";
        exit();
    }

    $query = "INSERT INTO books (title, author, category, status)
              VALUES ('$title', '$author', '$category', '$status')";

    if (mysqli_query($connection, $query)) {
        echo "✅ Book added successfully!";
    } else {
        echo "❌ Error: " . mysqli_error($connection);
    }
} else {
    echo "⚠️ Invalid request method.";
}
?>
