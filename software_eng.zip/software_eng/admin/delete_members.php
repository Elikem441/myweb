<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if ID is provided
if (!isset($_GET['id'])) {
    die("❌ Member ID not specified.");
}

$member_id = intval($_GET['id']);

// Only delete users with role = 'user'
$check_query = "SELECT role FROM users WHERE id = $member_id";
$result = mysqli_query($connection, $check_query);
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if ($row['role'] !== 'user') {
        die("❌ Cannot delete admin accounts.");
    }
} else {
    die("❌ Member not found.");
}

// Delete member
$delete_query = "DELETE FROM users WHERE id = $member_id";
if (mysqli_query($connection, $delete_query)) {
    header("Location: manage_members.php?deleted=1");
    exit();
} else {
    die("❌ Failed to delete member.");
}
?>
