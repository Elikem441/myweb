<?php
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");

if (!$connection) {
    die("❌ Database connection failed: " . mysqli_connect_error());
}
?>
