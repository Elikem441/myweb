<?php
// Show all errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Connect to database
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");

if (!$connection) {
    die("❌ Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if (isset($_POST['update'])) {
    $id       = intval($_POST['id']);
    $title    = mysqli_real_escape_string($connection, $_POST['title']);
    $author   = mysqli_real_escape_string($connection, $_POST['author']);
    $category = mysqli_real_escape_string($connection, $_POST['category']);
    $status   = mysqli_real_escape_string($connection, $_POST['status']);

    $updateQuery = "UPDATE books SET title='$title', author='$author', category='$category', status='$status' WHERE id=$id";

    if (mysqli_query($connection, $updateQuery)) {
        echo "✅ Book updated successfully. <a href='manage_books.php'>Go back</a>";
        exit();
    } else {
        echo "❌ Update failed: " . mysqli_error($connection);
    }
}

// Validate ID from URL
if (!isset($_GET['id'])) {
    die("❌ No book ID provided.");
}

$id = intval($_GET['id']);
$query = "SELECT * FROM books WHERE id = $id";
$result = mysqli_query($connection, $query);

if (!$result) {
    die("❌ SQL error: " . mysqli_error($connection));
}

if (mysqli_num_rows($result) !== 1) {
    die("❌ Book not found.");
}

$book = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Book | Admin | Library System</title>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background-color: #f4f6f9;
      padding: 40px;
      margin: 0;
    }

    .form-container {
      max-width: 600px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      margin-top: 15px;
      font-weight: bold;
    }

    input, select {
      padding: 10px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button {
      margin-top: 25px;
      background-color: #1abc9c;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #16a085;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>✏️ Edit Book</h2>
    <form method="POST" action="">
      <input type="hidden" name="id" value="<?php echo $book['id']; ?>">

      <label for="title">Title</label>
      <input type="text" name="title" value="<?php echo htmlspecialchars($book['title']); ?>" required>

      <label for="author">Author</label>
      <input type="text" name="author" value="<?php echo htmlspecialchars($book['author']); ?>" required>

      <label for="category">Category</label>
      <input type="text" name="category" value="<?php echo htmlspecialchars($book['category']); ?>">

      <label for="status">Status</label>
      <select name="status" required>
        <option value="Available" <?php if ($book['status'] === 'Available') echo 'selected'; ?>>Available</option>
        <option value="Borrowed" <?php if ($book['status'] === 'Borrowed') echo 'selected'; ?>>Borrowed</option>
      </select>

      <button type="submit" name="update">Update Book</button>
    </form>
  </div>

</body>
</html>
