<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$message = "";

// Get member ID from URL
if (!isset($_GET['id'])) {
    die("❌ Member ID is missing.");
}
$member_id = intval($_GET['id']);

// Fetch member data
$query = "SELECT * FROM users WHERE id = $member_id AND role = 'user'";
$result = mysqli_query($connection, $query);
if (!$result || mysqli_num_rows($result) == 0) {
    die("❌ Member not found.");
}
$member = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = $_POST['password'];

    $update_query = "UPDATE users SET name='$name', email='$email'";
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update_query .= ", password='$hashed_password'";
    }
    $update_query .= " WHERE id = $member_id";

    if (mysqli_query($connection, $update_query)) {
        $message = "✅ Member updated successfully.";
        // Refresh data
        $result = mysqli_query($connection, "SELECT * FROM users WHERE id = $member_id");
        $member = mysqli_fetch_assoc($result);
    } else {
        $message = "❌ Failed to update member: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Member</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      margin: 0;
    }

    .container {
      max-width: 500px;
      margin: 50px auto;
      padding: 25px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
    }

    form label {
      display: block;
      margin: 10px 0 5px;
      font-weight: bold;
    }

    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button {
      background-color: #1abc9c;
      color: white;
      border: none;
      padding: 12px;
      border-radius: 6px;
      width: 100%;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #16a085;
    }

    .message {
      text-align: center;
      margin-bottom: 20px;
      font-weight: bold;
    }

    .success {
      color: green;
    }

    .error {
      color: red;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Edit Member</h2>

    <?php if (!empty($message)): ?>
      <div class="message <?= str_contains($message, '❌') ? 'error' : 'success' ?>">
        <?= $message ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <label for="name">Full Name</label>
      <input type="text" name="name" id="name" value="<?= htmlspecialchars($member['name']) ?>" required>

      <label for="email">Email Address</label>
      <input type="email" name="email" id="email" value="<?= htmlspecialchars($member['email']) ?>" required>

      <label for="password">New Password (leave blank to keep current)</label>
      <input type="password" name="password" id="password">

      <button type="submit">Update Member</button>
    </form>
  </div>
</body>
</html>
