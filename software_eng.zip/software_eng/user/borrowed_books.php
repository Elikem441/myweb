<?php
session_start();
include '../admin/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "❌ You must be logged in to view this page.";
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch borrowed books for the logged-in user
$query = "SELECT b.title, b.author, bb.borrow_date, bb.due_date, bb.status
          FROM borrowed_books bb
          JOIN books b ON bb.book_id = b.id
          WHERE bb.user_id = $user_id
          ORDER BY bb.borrow_date DESC";

$result = mysqli_query($connection, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Borrowed Books</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }

    nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    nav a:hover {
      background-color: #1abc9c;
    }

    .container {
      max-width: 1000px;
      margin: 30px auto;
      padding: 20px;
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #2c3e50;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .status-returned {
      color: green;
      font-weight: bold;
    }

    .status-overdue {
      color: red;
      font-weight: bold;
    }

    .status-borrowed {
      color: orange;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <header>
    <h1><i class="fas fa-book"></i> Library Management System</h1>
  </header>

  <nav>
    <a href="search_books.php">Browse Books</a>
    <a href="borrowed_books.php">My Borrowed Books</a>
    <a href="return_books.php">Return books</a>
    <a href="my_profile.php">My Profile</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <h2>📚 My Borrowed Books</h2>

    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Author</th>
          <th>Borrow Date</th>
          <th>Due Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?= htmlspecialchars($row['title']) ?></td>
              <td><?= htmlspecialchars($row['author']) ?></td>
              <td><?= $row['borrow_date'] ?></td>
              <td><?= $row['due_date'] ?></td>
              <td class="<?= 'status-' . strtolower($row['status']) ?>">
                <?= htmlspecialchars($row['status']) ?>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" style="text-align:center;">No borrowed books found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</body>
</html>
