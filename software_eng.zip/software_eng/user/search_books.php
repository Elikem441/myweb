<?php
// db connection
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

$search = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($connection, $_GET['search']);
    $query = "SELECT * FROM books WHERE 
              title LIKE '%$search%' OR 
              author LIKE '%$search%' OR 
              category LIKE '%$search%'";
} else {
    $query = "SELECT * FROM books";
}
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Browse Books | Library Management System</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f6f9;
    }
    header {
      background-color: #2c3e50;
      padding: 20px;
      color: white;
      text-align: center;
    }
    nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    nav a:hover {
      background-color: #1abc9c;
    }
    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    .search-bar {
      text-align: center;
      margin-bottom: 30px;
    }
    .search-bar form input {
      width: 80%;
      max-width: 500px;
      padding: 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    .book-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
    }
    .book-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s;
      padding: 15px;
      text-align: center;
    }
    .book-card:hover {
      transform: scale(1.02);
    }
    .book-details h3 {
      font-size: 18px;
      margin: 10px 0 5px;
      color: #2c3e50;
    }
    .book-details p {
      margin: 0;
      color: #555;
      font-size: 14px;
    }
    .status {
      margin: 10px 0;
      font-weight: bold;
      color: #1abc9c;
    }
    .status.unavailable {
      color: red;
    }
    .borrow-btn {
      background-color: #1abc9c;
      color: white;
      padding: 8px 14px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      margin-top: 10px;
    }
    .borrow-btn:disabled {
      background-color: #bdc3c7;
      cursor: not-allowed;
    }
  </style>
</head>
<body>

  <header>
    <h1><i class="fas fa-book"></i> Library Management System</h1>
  </header>

  <nav>
    <a href="search_books.php">Browse Books</a>
    <a href="borrowed_books.php">My Borrowed Books</a>
    <a href="return_books.php">Return books</a>
    <a href="my_profile.php">My Profile</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <h2>📖 Browse Available Books</h2>

    <div class="search-bar">
      <form method="GET" action="">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search by title, author, or genre...">
      </form>
    </div>

    <div class="book-grid">
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <div class="book-card">
            <div class="book-details">
              <h3><?= htmlspecialchars($row['title']) ?></h3>
              <p><?= htmlspecialchars($row['author']) ?></p>
              <p class="status <?= $row['status'] == 'Borrowed' ? 'unavailable' : '' ?>">
                <?= htmlspecialchars($row['status']) ?>
              </p>
              <?php if ($row['status'] == 'Available'): ?>
               <a class="borrow-btn" href="borrow_book.php?book_id=<?= $row['id'] ?>">Borrow</a>

              <?php else: ?>
                <button class="borrow-btn" disabled>Not Available</button>
              <?php endif; ?>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p style="text-align: center;">No books found.</p>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>
