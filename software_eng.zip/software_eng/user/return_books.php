<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.html");
    exit();
}

include '../admin/db.php';

$user_id = $_SESSION['user_id'];
$message = "";

// Handle return
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $borrow_id = intval($_POST['borrowed_book']);
    $return_date = $_POST['return_date'];

    // Get book ID from borrowed_books
    $stmt = mysqli_prepare($connection, "SELECT book_id FROM borrowed_books WHERE id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $borrow_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $book_id = $row['book_id'];

        // Update borrowed_books: set return_date and status to 'Returned'
        $stmt1 = mysqli_prepare($connection, "UPDATE borrowed_books SET return_date = ?, status = 'Returned' WHERE id = ?");
        mysqli_stmt_bind_param($stmt1, "si", $return_date, $borrow_id);
        $success1 = mysqli_stmt_execute($stmt1);

        // Update books: set status to 'Available'
        $stmt2 = mysqli_prepare($connection, "UPDATE books SET status = 'Available' WHERE id = ?");
        mysqli_stmt_bind_param($stmt2, "i", $book_id);
        $success2 = mysqli_stmt_execute($stmt2);

        if ($success1 && $success2) {
            $message = "✅ Book returned successfully!";
        } else {
            $message = "❌ Failed to return book.";
        }
    } else {
        $message = "❌ Invalid borrowed book selection.";
    }
}

// Fetch borrowed books for dropdown
$borrowed_query = "SELECT bb.id, b.title, u.name, bb.due_date
                   FROM borrowed_books bb
                   JOIN books b ON bb.book_id = b.id
                   JOIN users u ON bb.user_id = u.id
                   WHERE bb.user_id = $user_id AND bb.status = 'Borrowed'";

$borrowed_result = mysqli_query($connection, $borrowed_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Return Book - Library System</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
    }

    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }
        nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    nav a:hover {
      background-color: #1abc9c;
    }

    .container {
      padding: 30px;
      max-width: 600px;
      margin: auto;
    }

    h2 {
      color: #2c3e50;
      margin-bottom: 20px;
    }

    form {
      background-color: white;
      padding: 25px;
      border-radius: 6px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }

    select, input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      margin-bottom: 15px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }

    button {
      background-color: #1abc9c;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #16a085;
    }

    .message {
      margin-top: 20px;
      font-weight: bold;
      color: green;
    }
    .error {
      color: red;
    }
  </style>
</head>
<body>

  <header>
    <h1>Library Management System</h1>
    <h2>Return a Book</h2>
  </header>
  <nav>
    <a href="search_books.php">Browse Books</a>
    <a href="borrowed_books.php">My Borrowed Books</a>
    <a href="return_books.php">Return books</a>
    <a href="my_profile.php">My Profile</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <?php if (!empty($message)): ?>
      <div class="message <?= str_contains($message, '❌') ? 'error' : '' ?>">
        <?= $message ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="return_books.php">
      <label for="borrowed_book">Select Borrowed Book</label>
      <select id="borrowed_book" name="borrowed_book" required>
        <option value="">-- Choose a Book to Return --</option>
        <?php while ($row = mysqli_fetch_assoc($borrowed_result)): ?>
          <option value="<?= $row['id'] ?>">
            <?= htmlspecialchars($row['title']) ?> (Due: <?= $row['due_date'] ?>)
          </option>
        <?php endwhile; ?>
      </select>

      <label for="return_date">Return Date</label>
      <input type="date" id="return_date" name="return_date" required value="<?= date('Y-m-d') ?>" />

      <button type="submit">Return</button>
    </form>
  </div>

</body>
</html>
