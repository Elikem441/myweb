<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.html");
    exit();
}

include '../admin/db.php';

$user_id = $_SESSION['user_id'];
$message = "";

// Handle updates
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $update_query = "UPDATE users SET name='$name', email='$email'";

    if (!empty($_POST['new_password'])) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $update_query .= ", password='$new_password'";
    }

    $update_query .= " WHERE id=$user_id";

    if (mysqli_query($connection, $update_query)) {
        $message = "✅ Profile updated successfully!";
    } else {
        $message = "❌ Failed to update profile.";
    }
}

// Fetch user data
$query = "SELECT name, email, member_id FROM users WHERE id = $user_id";
$result = mysqli_query($connection, $query);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Profile | Library System</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background-color: #f4f4f4;
      margin: 0;
    }

    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }

    .container {
      width: 500px;
      margin: 40px auto;
      background-color: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    }

        nav {
      background-color: #34495e;
      padding: 15px 30px;
      display: flex;
      justify-content: center;
      gap: 40px;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    nav a:hover {
      background-color: #1abc9c;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }

    input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }

    button {
      background-color: #1abc9c;
      color: white;
      border: none;
      padding: 12px;
      width: 100%;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #16a085;
    }

    .message {
      margin-bottom: 20px;
      font-weight: bold;
      color: green;
    }

    .error {
      color: red;
    }
  </style>
</head>
<body>

  <header>
    <h1><i class="fas fa-user"></i> My Profile</h1>
  </header>

    <nav>
    <a href="search_books.php">Browse Books</a>
    <a href="borrowed_books.php">My Borrowed Books</a>
    <a href="return_books.php">Return books</a>
    <a href="my_profile.php">My Profile</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>

  <div class="container">
    <h2><i class="fas fa-id-badge"></i> Account Information</h2>

    <?php if (!empty($message)): ?>
      <div class="message <?= str_contains($message, '❌') ? 'error' : '' ?>">
        <?= $message ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="my_profile.php">
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
      </div>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
      </div>
      <div class="form-group">
        <label>Member ID</label>
        <input type="text" name="member_id" value="<?= htmlspecialchars($user['member_id']) ?>" disabled>
      </div>
      <div class="form-group">
        <label>Change Password (optional)</label>
        <input type="password" name="new_password" placeholder="New Password">
      </div>
      <button type="submit">Update Profile</button>
    </form>
  </div>

</body>
</html>
