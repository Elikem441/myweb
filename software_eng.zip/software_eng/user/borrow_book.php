<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../admin/db.php';


// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "❌ You must be logged in to borrow a book.";
    exit;
}

// Validate book ID
if (!isset($_GET['book_id']) || !is_numeric($_GET['book_id'])) {
    echo "❌ No book ID provided.";
    exit;
}

$book_id = intval($_GET['book_id']);
$user_id = $_SESSION['user_id'];

// Check if book is available
$book_query = "SELECT * FROM books WHERE id = $book_id AND status = 'Available'";
$book_result = mysqli_query($connection, $book_query);

if (!$book_result || mysqli_num_rows($book_result) === 0) {
    echo "❌ Book not found or not available.";
    exit;
}

// Update books table to mark it as borrowed
$update_status = "UPDATE books SET status = 'Borrowed' WHERE id = $book_id";

// Insert into borrowed_books table
$borrow_query = "INSERT INTO borrowed_books (user_id, book_id, borrow_date, due_date, status) 
                 VALUES ($user_id, $book_id, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), 'Borrowed')";

// Execute both queries
if (mysqli_query($connection, $update_status) && mysqli_query($connection, $borrow_query)) {
    header("Location: borrowed_books.php");
    exit;
} else {
    echo "❌ Failed to borrow book.";
}
?>
