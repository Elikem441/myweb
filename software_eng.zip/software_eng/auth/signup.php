<?php
// Show all PHP errors (for debugging - disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$connection = mysqli_connect("localhost", "root", "", "admin_library_system");

if (!$connection) {
    http_response_code(500); // Internal Server Error
    echo "Database connection failed.";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize user input
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $member_id = mysqli_real_escape_string($connection, $_POST['member_id']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password hash
    $role = 'user'; // Default role

    // Optional: Check if email already exists
    $checkEmail = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($connection, $checkEmail);

    if (mysqli_num_rows($result) > 0) {
        echo "This email is already registered.";
        exit();
    }

    // Insert into users table
    $query = "INSERT INTO users (name, member_id, email, password, role)
              VALUES ('$name', '$member_id', '$email', '$password', '$role')";

    if (mysqli_query($connection, $query)) {
        echo "success"; // This is what the JavaScript checks for
    } else {
        echo "Error saving user: " . mysqli_error($connection);
    }

} else {
    echo "Invalid request method.";
}
?>
